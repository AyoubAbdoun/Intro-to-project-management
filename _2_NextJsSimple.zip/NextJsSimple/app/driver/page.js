'use client'

import { useState, useEffect } from 'react'
import { CAMPUS_STOPS } from '@/lib/store'
import SimpleMap from '@/components/SimpleMap'

export default function DriverPage() {
  const [pendingRides, setPendingRides] = useState([])
  const [currentRide, setCurrentRide] = useState(null)
  const [shuttle, setShuttle] = useState(null)
  const [ws, setWs] = useState(null)

  // Fetch initial data
  useEffect(() => {
    fetchPendingRides()
    fetchShuttleStatus()
  }, [])

  // WebSocket connection for real-time updates
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const wsUrl = `${protocol}//${window.location.host}/ws`
    
    try {
      const websocket = new WebSocket(wsUrl)
      
      websocket.onopen = () => {
        console.log('Driver WebSocket connected')
      }
      
      websocket.onmessage = (event) => {
        const data = JSON.parse(event.data)
        
        if (data.type === 'new-ride') {
          setPendingRides(prev => [...prev, data.ride])
        } else if (data.type === 'ride-update') {
          setPendingRides(prev => prev.filter(r => r.id !== data.ride.id))
          setCurrentRide(prevRide => {
            if (prevRide && data.ride.id === prevRide.id) {
              return data.ride
            }
            return prevRide
          })
        } else if (data.type === 'shuttle-update') {
          setShuttle(data.shuttle)
        }
      }
      
      websocket.onerror = (error) => {
        console.log('WebSocket error:', error)
        setWs(null)
      }
      
      websocket.onclose = () => {
        console.log('WebSocket closed')
        setWs(null)
      }
      
      setWs(websocket)
      
      return () => {
        if (websocket.readyState === 1) {
          websocket.close()
        }
      }
    } catch (error) {
      console.log('WebSocket not available, using polling fallback')
    }
  }, [])

  // Poll for updates if WebSocket not available
  useEffect(() => {
    if (ws) return
    
    const interval = setInterval(() => {
      fetchPendingRides()
      fetchShuttleStatus()
    }, 3000)
    
    return () => clearInterval(interval)
  }, [ws])

  const fetchPendingRides = async () => {
    try {
      const response = await fetch('/api/rides')
      const rides = await response.json()
      setPendingRides(rides)
    } catch (error) {
      console.error('Error fetching rides:', error)
    }
  }

  const fetchShuttleStatus = async () => {
    try {
      const response = await fetch('/api/shuttle')
      const shuttleData = await response.json()
      setShuttle(shuttleData)
      
      if (shuttleData.currentRideId) {
        const rideResponse = await fetch(`/api/rides?id=${shuttleData.currentRideId}`)
        const ride = await rideResponse.json()
        setCurrentRide(ride)
      }
    } catch (error) {
      console.error('Error fetching shuttle status:', error)
    }
  }

  const handleAcceptRide = async (ride) => {
    try {
      await fetch('/api/rides', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rideId: ride.id,
          status: 'matched',
        }),
      })
      
      setCurrentRide(ride)
      setPendingRides(prev => prev.filter(r => r.id !== ride.id))
    } catch (error) {
      console.error('Error accepting ride:', error)
    }
  }

  const handleStartTrip = async () => {
    if (!currentRide) return
    
    try {
      await fetch('/api/rides', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rideId: currentRide.id,
          status: 'in-transit',
        }),
      })
      
      setCurrentRide({ ...currentRide, status: 'in-transit' })
    } catch (error) {
      console.error('Error starting trip:', error)
    }
  }

  const handleCompleteTrip = async () => {
    if (!currentRide) return
    
    try {
      await fetch('/api/rides', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rideId: currentRide.id,
          status: 'completed',
        }),
      })
      
      setCurrentRide(null)
      fetchShuttleStatus()
    } catch (error) {
      console.error('Error completing trip:', error)
    }
  }

  const handleSimulateMovement = async (stopId) => {
    const stop = CAMPUS_STOPS.find(s => s.id === stopId)
    if (!stop) return
    
    try {
      await fetch('/api/shuttle', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          lat: stop.lat,
          lon: stop.lon,
        }),
      })
    } catch (error) {
      console.error('Error updating shuttle location:', error)
    }
  }

  const getStopName = (stopId) => {
    return CAMPUS_STOPS.find(s => s.id === stopId)?.name || stopId
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-500 to-green-700 p-4 safe-area">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-6 mb-4">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">🚍 Driver Dashboard</h1>

          {/* Map Visualization */}
          {shuttle && (
            <div className="mb-6">
              <SimpleMap 
                stops={CAMPUS_STOPS} 
                shuttleLocation={shuttle}
                highlightStops={currentRide ? [currentRide.pickup, currentRide.destination] : []}
              />
            </div>
          )}

          {/* Shuttle Status */}
          {shuttle && (
            <div className="bg-green-100 border-2 border-green-500 rounded-xl p-4 mb-6">
              <div className="font-bold text-green-800 mb-2">Shuttle Status</div>
              <div className="text-sm text-green-700">
                <div><strong>Status:</strong> <span className="capitalize">{shuttle.status}</span></div>
                <div><strong>Driver:</strong> {shuttle.driver}</div>
                <div><strong>Location:</strong> {shuttle.lat.toFixed(4)}, {shuttle.lon.toFixed(4)}</div>
              </div>
            </div>
          )}

          {/* Current Ride */}
          {currentRide && currentRide.status !== 'completed' && (
            <div className="bg-blue-100 border-2 border-blue-500 rounded-xl p-4 mb-6">
              <div className="font-bold text-blue-800 mb-3 text-lg">Current Ride #{currentRide.id}</div>
              <div className="text-sm text-blue-700 mb-4 space-y-1">
                <div><strong>Pickup:</strong> {getStopName(currentRide.pickup)}</div>
                <div><strong>Destination:</strong> {getStopName(currentRide.destination)}</div>
                <div><strong>Status:</strong> <span className="capitalize">{currentRide.status}</span></div>
              </div>
              
              <div className="space-y-2">
                {currentRide.status === 'matched' && (
                  <>
                    <button
                      onClick={handleStartTrip}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-xl transition-all"
                    >
                      Start Trip
                    </button>
                    <div className="text-xs text-blue-600 font-semibold">📍 Demo: Move shuttle to pickup</div>
                    <button
                      onClick={() => handleSimulateMovement(currentRide.pickup)}
                      className="w-full bg-blue-200 hover:bg-blue-300 text-blue-800 py-2 px-4 rounded-lg text-sm"
                    >
                      Simulate: Arrive at {getStopName(currentRide.pickup)}
                    </button>
                  </>
                )}
                
                {currentRide.status === 'in-transit' && (
                  <>
                    <button
                      onClick={handleCompleteTrip}
                      className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-xl transition-all"
                    >
                      Complete Trip
                    </button>
                    <div className="text-xs text-blue-600 font-semibold">📍 Demo: Move shuttle to destination</div>
                    <button
                      onClick={() => handleSimulateMovement(currentRide.destination)}
                      className="w-full bg-blue-200 hover:bg-blue-300 text-blue-800 py-2 px-4 rounded-lg text-sm"
                    >
                      Simulate: Arrive at {getStopName(currentRide.destination)}
                    </button>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Pending Rides Queue */}
          <div className="mb-6">
            <div className="font-bold text-gray-800 mb-3 text-lg flex items-center justify-between">
              <span>Pending Requests</span>
              <span className="bg-yellow-500 text-white text-sm px-3 py-1 rounded-full">
                {pendingRides.length}
              </span>
            </div>
            
            {pendingRides.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                <div className="text-4xl mb-2">✅</div>
                <p>No pending ride requests</p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingRides.map(ride => (
                  <div key={ride.id} className="bg-yellow-50 border-2 border-yellow-500 rounded-xl p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div className="text-sm">
                        <div className="font-bold text-yellow-800">Ride #{ride.id}</div>
                        <div className="text-yellow-700 mt-1">
                          <div><strong>From:</strong> {getStopName(ride.pickup)}</div>
                          <div><strong>To:</strong> {getStopName(ride.destination)}</div>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleAcceptRide(ride)}
                      disabled={currentRide !== null}
                      className={`w-full ${currentRide ? 'bg-gray-400' : 'bg-yellow-600 hover:bg-yellow-700'} text-white font-bold py-2 px-4 rounded-lg transition-all`}
                    >
                      {currentRide ? 'Busy with another ride' : 'Accept Ride'}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="text-center">
          <a href="/" className="text-white underline">← Back to Home</a>
        </div>
      </div>
    </div>
  )
}
