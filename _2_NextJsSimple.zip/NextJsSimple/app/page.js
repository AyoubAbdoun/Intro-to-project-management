'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function Home() {
  const router = useRouter()

  useEffect(() => {
    router.push('/student')
  }, [router])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-b from-blue-500 to-blue-700">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">🚍</h1>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">CampusDemand</h2>
        <p className="text-gray-600">Loading...</p>
      </div>
    </div>
  )
}
