import { NextResponse } from 'next/server'

// WebSocket endpoint information
export async function GET() {
  return NextResponse.json({
    message: 'WebSocket server is available at ws://localhost:5000/ws',
    note: 'This is handled by the standalone WebSocket server'
  })
}
