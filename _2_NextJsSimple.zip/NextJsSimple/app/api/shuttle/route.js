import { NextResponse } from 'next/server'
import { getShuttleStatus, updateShuttleLocation } from '@/lib/store'

// GET - Get shuttle status and location
export async function GET() {
  const shuttle = getShuttleStatus()
  return NextResponse.json(shuttle)
}

// PUT - Update shuttle location
export async function PUT(request) {
  try {
    const body = await request.json()
    const { lat, lon } = body
    
    if (lat === undefined || lon === undefined) {
      return NextResponse.json(
        { error: 'Missing required fields: lat, lon' },
        { status: 400 }
      )
    }
    
    updateShuttleLocation(lat, lon)
    const shuttle = getShuttleStatus()
    return NextResponse.json(shuttle)
  } catch (error) {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 })
  }
}
