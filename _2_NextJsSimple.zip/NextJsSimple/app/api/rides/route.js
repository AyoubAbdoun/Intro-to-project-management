import { NextResponse } from 'next/server'
import { createRide, getPendingRides, getRide, updateRideStatus } from '@/lib/store'

// GET - Get all pending rides or a specific ride
export async function GET(request) {
  const { searchParams } = new URL(request.url)
  const rideId = searchParams.get('id')
  
  if (rideId) {
    const ride = getRide(rideId)
    if (!ride) {
      return NextResponse.json({ error: 'Ride not found' }, { status: 404 })
    }
    return NextResponse.json(ride)
  }
  
  const pendingRides = getPendingRides()
  return NextResponse.json(pendingRides)
}

// POST - Create a new ride request
export async function POST(request) {
  try {
    const body = await request.json()
    const { pickup, destination, studentLocation } = body
    
    if (!pickup || !destination || !studentLocation) {
      return NextResponse.json(
        { error: 'Missing required fields: pickup, destination, studentLocation' },
        { status: 400 }
      )
    }
    
    const ride = createRide(pickup, destination, studentLocation)
    return NextResponse.json(ride, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 })
  }
}

// PUT - Update ride status
export async function PUT(request) {
  try {
    const body = await request.json()
    const { rideId, status } = body
    
    if (!rideId || !status) {
      return NextResponse.json(
        { error: 'Missing required fields: rideId, status' },
        { status: 400 }
      )
    }
    
    const ride = updateRideStatus(rideId, status)
    if (!ride) {
      return NextResponse.json({ error: 'Ride not found' }, { status: 404 })
    }
    
    return NextResponse.json(ride)
  } catch (error) {
    return NextResponse.json({ error: 'Invalid request body' }, { status: 400 })
  }
}
