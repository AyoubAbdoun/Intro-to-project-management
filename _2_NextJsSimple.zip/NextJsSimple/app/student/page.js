'use client'

import { useState, useEffect } from 'react'
import { CAMPUS_STOPS, SRZ_RADIUS } from '@/lib/store'

export default function StudentPage() {
  const [selectedPickup, setSelectedPickup] = useState(null)
  const [selectedDestination, setSelectedDestination] = useState(null)
  const [studentLocation, setStudentLocation] = useState(null)
  const [isWithinZone, setIsWithinZone] = useState(false)
  const [currentRide, setCurrentRide] = useState(null)
  const [ws, setWs] = useState(null)

  // Simulate student location (in real app, use GPS)
  useEffect(() => {
    // Default to near Main Library
    setStudentLocation({
      lat: 40.7128,
      lon: -74.0060
    })
  }, [])

  // Check if student is within SRZ of selected pickup
  useEffect(() => {
    if (selectedPickup && studentLocation) {
      const pickup = CAMPUS_STOPS.find(s => s.id === selectedPickup)
      if (pickup) {
        const distance = Math.sqrt(
          Math.pow(studentLocation.lat - pickup.lat, 2) +
          Math.pow(studentLocation.lon - pickup.lon, 2)
        )
        setIsWithinZone(distance <= SRZ_RADIUS)
      }
    }
  }, [selectedPickup, studentLocation])

  // WebSocket connection for real-time updates
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const wsUrl = `${protocol}//${window.location.host}/ws`
    
    try {
      const websocket = new WebSocket(wsUrl)
      
      websocket.onopen = () => {
        console.log('WebSocket connected')
      }
      
      websocket.onmessage = (event) => {
        const data = JSON.parse(event.data)
        
        if (data.type === 'ride-update') {
          setCurrentRide(prevRide => {
            if (prevRide && data.ride.id === prevRide.id) {
              return data.ride
            }
            return prevRide
          })
        }
      }
      
      websocket.onerror = (error) => {
        console.log('WebSocket error:', error)
        setWs(null)
      }
      
      websocket.onclose = () => {
        console.log('WebSocket closed')
        setWs(null)
      }
      
      setWs(websocket)
      
      return () => {
        if (websocket.readyState === 1) {
          websocket.close()
        }
      }
    } catch (error) {
      console.log('WebSocket not available, using polling fallback')
    }
  }, [])

  // Poll for ride updates if WebSocket not available
  useEffect(() => {
    if (!currentRide || ws) return
    
    const interval = setInterval(async () => {
      try {
        const response = await fetch(`/api/rides?id=${currentRide.id}`)
        const ride = await response.json()
        setCurrentRide(ride)
        
        if (ride.status === 'completed' || ride.status === 'cancelled') {
          clearInterval(interval)
        }
      } catch (error) {
        console.error('Error polling ride status:', error)
      }
    }, 2000)
    
    return () => clearInterval(interval)
  }, [currentRide, ws])

  const handleRequestRide = async () => {
    if (!selectedPickup || !selectedDestination || !isWithinZone) {
      return
    }

    try {
      const response = await fetch('/api/rides', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pickup: selectedPickup,
          destination: selectedDestination,
          studentLocation,
        }),
      })

      const ride = await response.json()
      setCurrentRide(ride)
    } catch (error) {
      console.error('Error requesting ride:', error)
    }
  }

  const handleCancelRide = async () => {
    if (!currentRide) return

    try {
      await fetch('/api/rides', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rideId: currentRide.id,
          status: 'cancelled',
        }),
      })

      setCurrentRide(null)
    } catch (error) {
      console.error('Error cancelling ride:', error)
    }
  }

  // Simulate location change (for demo)
  const handleLocationChange = (stopId) => {
    const stop = CAMPUS_STOPS.find(s => s.id === stopId)
    if (stop) {
      setStudentLocation({
        lat: stop.lat + (Math.random() - 0.5) * 0.0002,
        lon: stop.lon + (Math.random() - 0.5) * 0.0002,
      })
    }
  }

  const getButtonState = () => {
    if (!selectedPickup || !selectedDestination) {
      return { text: 'Select Pickup & Destination', color: 'bg-gray-400', disabled: true }
    }
    
    if (!isWithinZone) {
      return { text: 'Move Closer to Pickup Location', color: 'bg-yellow-500', disabled: true }
    }
    
    return { text: 'Request Shuttle', color: 'bg-blue-600 hover:bg-blue-700', disabled: false }
  }

  const getRideStatusColor = (status) => {
    switch (status) {
      case 'requested': return 'bg-yellow-100 border-yellow-500 text-yellow-800'
      case 'matched': return 'bg-blue-100 border-blue-500 text-blue-800'
      case 'in-transit': return 'bg-green-100 border-green-500 text-green-800'
      case 'completed': return 'bg-gray-100 border-gray-500 text-gray-800'
      default: return 'bg-gray-100 border-gray-500 text-gray-800'
    }
  }

  const buttonState = getButtonState()

  if (currentRide && currentRide.status !== 'completed' && currentRide.status !== 'cancelled') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-500 to-blue-700 p-4 safe-area">
        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-2xl shadow-2xl p-6 mb-4">
            <h1 className="text-2xl font-bold text-gray-900 mb-2">🚍 Your Ride</h1>
            
            <div className={`border-2 rounded-xl p-4 mb-4 ${getRideStatusColor(currentRide.status)}`}>
              <div className="text-lg font-bold mb-2 capitalize">{currentRide.status}</div>
              <div className="space-y-1 text-sm">
                <div><strong>From:</strong> {CAMPUS_STOPS.find(s => s.id === currentRide.pickup)?.name}</div>
                <div><strong>To:</strong> {CAMPUS_STOPS.find(s => s.id === currentRide.destination)?.name}</div>
                <div><strong>Ride ID:</strong> #{currentRide.id}</div>
              </div>
            </div>

            {currentRide.status === 'requested' && (
              <div className="text-center text-gray-600 mb-4">
                <div className="animate-pulse text-4xl mb-2">⏳</div>
                <p>hold on the tram is arriving</p>
              </div>
            )}

            {currentRide.status === 'matched' && (
              <div className="text-center text-gray-600 mb-4">
                <div className="animate-bounce text-4xl mb-2">🚍</div>
                <p>Shuttle is on the way!</p>
              </div>
            )}

            {currentRide.status === 'in-transit' && (
              <div className="text-center text-gray-600 mb-4">
                <div className="text-4xl mb-2">✅</div>
                <p>Enjoy your ride!</p>
              </div>
            )}

            <button
              onClick={handleCancelRide}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-xl transition-all"
            >
              Cancel Ride
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-500 to-blue-700 p-4 safe-area">
      <div className="max-w-md mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-6 mb-4">
          <h1 className="text-3xl font-bold text-gray-900 mb-6 text-center">🚍 Request Shuttle</h1>

          {/* Pickup Selection */}
          <div className="mb-6">
            <label className="block text-sm font-bold text-gray-700 mb-2">
              Pickup Location
            </label>
            <select
              value={selectedPickup || ''}
              onChange={(e) => setSelectedPickup(e.target.value)}
              className="w-full p-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none"
            >
              <option value="">Select pickup location</option>
              {CAMPUS_STOPS.map(stop => (
                <option key={stop.id} value={stop.id}>{stop.name}</option>
              ))}
            </select>
          </div>

          {/* Destination Selection */}
          <div className="mb-6">
            <label className="block text-sm font-bold text-gray-700 mb-2">
              Destination
            </label>
            <select
              value={selectedDestination || ''}
              onChange={(e) => setSelectedDestination(e.target.value)}
              className="w-full p-3 border-2 border-gray-300 rounded-xl focus:border-blue-500 focus:outline-none"
            >
              <option value="">Select destination</option>
              {CAMPUS_STOPS.filter(s => s.id !== selectedPickup).map(stop => (
                <option key={stop.id} value={stop.id}>{stop.name}</option>
              ))}
            </select>
          </div>

          {/* Proximity Status */}
          {selectedPickup && (
            <div className={`mb-6 p-4 rounded-xl ${isWithinZone ? 'bg-green-100 border-2 border-green-500' : 'bg-yellow-100 border-2 border-yellow-500'}`}>
              <div className="flex items-center space-x-2">
                <span className="text-2xl">{isWithinZone ? '✅' : '⚠️'}</span>
                <div>
                  <div className="font-bold text-sm">
                    {isWithinZone ? 'Within Request Zone' : 'Too Far From Pickup'}
                  </div>
                  <div className="text-xs">
                    {isWithinZone 
                      ? 'You can request a shuttle now' 
                      : 'Move closer to the pickup location'}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Request Button */}
          <button
            onClick={handleRequestRide}
            disabled={buttonState.disabled}
            className={`w-full ${buttonState.color} text-white font-bold py-4 px-6 rounded-xl text-lg transition-all transform ${buttonState.disabled ? 'cursor-not-allowed' : 'hover:scale-105'} shadow-lg mb-4`}
          >
            {buttonState.text}
          </button>

          {/* Demo Controls */}
          <div className="mt-6 pt-6 border-t-2 border-gray-200">
            <div className="text-xs font-bold text-gray-700 mb-2">📍 DEMO: Simulate Your Location</div>
            <div className="grid grid-cols-2 gap-2">
              {CAMPUS_STOPS.slice(0, 4).map(stop => (
                <button
                  key={stop.id}
                  onClick={() => handleLocationChange(stop.id)}
                  className="text-xs bg-gray-200 hover:bg-gray-300 px-3 py-2 rounded-lg"
                >
                  Near {stop.name.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="text-center">
          <a href="/" className="text-white underline">← Back to Home</a>
        </div>
      </div>
    </div>
  )
}
