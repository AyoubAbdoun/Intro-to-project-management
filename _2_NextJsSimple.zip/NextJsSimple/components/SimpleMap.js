'use client'

import { useEffect, useRef } from 'react'

export default function SimpleMap({ stops = [], shuttleLocation, highlightStops = [] }) {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    const width = canvas.width
    const height = canvas.height

    ctx.clearRect(0, 0, width, height)

    // Background
    ctx.fillStyle = '#f0f9ff'
    ctx.fillRect(0, 0, width, height)

    // Grid
    ctx.strokeStyle = '#e0e7ff'
    ctx.lineWidth = 1
    for (let i = 0; i < width; i += 30) {
      ctx.beginPath()
      ctx.moveTo(i, 0)
      ctx.lineTo(i, height)
      ctx.stroke()
    }
    for (let i = 0; i < height; i += 30) {
      ctx.beginPath()
      ctx.moveTo(0, i)
      ctx.lineTo(width, i)
      ctx.stroke()
    }

    // Find bounds for scaling
    const allPoints = [...stops.map(s => ({ lat: s.lat, lon: s.lon }))]
    if (shuttleLocation) {
      allPoints.push({ lat: shuttleLocation.lat, lon: shuttleLocation.lon })
    }

    if (allPoints.length === 0) return

    const minLat = Math.min(...allPoints.map(p => p.lat))
    const maxLat = Math.max(...allPoints.map(p => p.lat))
    const minLon = Math.min(...allPoints.map(p => p.lon))
    const maxLon = Math.max(...allPoints.map(p => p.lon))

    const latRange = maxLat - minLat || 0.001
    const lonRange = maxLon - minLon || 0.001

    const padding = 40
    const scaleX = (width - 2 * padding) / lonRange
    const scaleY = (height - 2 * padding) / latRange

    const toX = (lon) => padding + (lon - minLon) * scaleX
    const toY = (lat) => height - (padding + (lat - minLat) * scaleY)

    // Draw stops
    stops.forEach((stop) => {
      const x = toX(stop.lon)
      const y = toY(stop.lat)
      const isHighlighted = highlightStops.includes(stop.id)

      // Stop circle
      ctx.beginPath()
      ctx.arc(x, y, isHighlighted ? 12 : 8, 0, 2 * Math.PI)
      ctx.fillStyle = isHighlighted ? '#3b82f6' : '#64748b'
      ctx.fill()
      ctx.strokeStyle = isHighlighted ? '#1e40af' : '#475569'
      ctx.lineWidth = 2
      ctx.stroke()

      // Stop label
      ctx.fillStyle = '#1e293b'
      ctx.font = isHighlighted ? 'bold 11px sans-serif' : '10px sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText(stop.name.split(' ')[0], x, y + 25)
    })

    // Draw shuttle
    if (shuttleLocation) {
      const x = toX(shuttleLocation.lon)
      const y = toY(shuttleLocation.lat)

      // Shuttle icon (larger circle)
      ctx.beginPath()
      ctx.arc(x, y, 15, 0, 2 * Math.PI)
      ctx.fillStyle = '#10b981'
      ctx.fill()
      ctx.strokeStyle = '#047857'
      ctx.lineWidth = 3
      ctx.stroke()

      // Shuttle symbol
      ctx.fillStyle = '#ffffff'
      ctx.font = 'bold 16px sans-serif'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText('🚍', x, y)
    }
  }, [stops, shuttleLocation, highlightStops])

  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg">
      <canvas
        ref={canvasRef}
        width={350}
        height={250}
        className="w-full"
      />
    </div>
  )
}
